<?php
/**
 * Created by PhpStorm.
 * User: Hider
 * Date: 2017/12/5
 * Time: 23:21
 */

include (ROOT."/view/dataAdd.html");