<?php

setcookie('name', null, 0);
header('Location:login.php');