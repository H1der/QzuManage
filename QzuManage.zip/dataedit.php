<?php
/**
 * Created by PhpStorm.
 * User: Hider
 * Date: 2017/12/7
 * Time: 20:50
 */

include (ROOT."/view/dataedit.html");
