<?php
/**
 * Created by PhpStorm.
 * User: Hider
 * Date: 2017/8/16
 * Time: 23:57
 */
return array(
    'host'=>'mysql.coding.io',
    'user'=>'user-KEg0UR5EBL',
    'password'=>'QWA+^[*GXw:-2glX{lz3',
    'db'=>'db-2mUqifm8Fc',
    'salt' => 'L^&%TDJ}',
);
